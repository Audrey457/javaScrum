package view;

import javax.swing.JButton;
import javax.swing.JFrame;

public class DBManagementFrame extends JFrame {
	private JButton create, update;
	
	public DBManagementFrame(){
		super();
	}
}
